package movie_api.repository;

import java.util.Collection;

import org.springframework.stereotype.Repository;

import movie_api.entity.Movie;
import movie_api.store.MovieStore;

@Repository //Marks this class as a Repository
public class MovieRepository {//This is a repository used to interact with MovieStore
	public Collection<Movie> getAllMovies(){
		Collection<Movie> allMovies = MovieStore.getAllAvailableMovies();
		return allMovies;
	}
	
	public Movie getMovieById(Integer movieId) {
		Movie foundMovie = MovieStore.getMovieById(movieId);
		return foundMovie;
	}
	
	public void addNewMovie(Movie newMovie) {
		MovieStore.addNewMovie(newMovie);
	}
}







