package movie_api.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import movie_api.entity.Movie;
import movie_api.repository.MovieRepository;

@Service //Marks this class as a Service Implementation class.
public class MovieService {//This class is meant for handling Business Logic if any. 
	//It interacts with MovieRepository
	@Autowired//Injecting the reference of MovieRepository
	private MovieRepository movieRepositoryRef;
	public Collection<Movie> getAllMovies(){
		Collection<Movie> allMovies = 	movieRepositoryRef.getAllMovies();
		return allMovies;		
	}
	
	public Movie getMovieById(Integer movieId) {
		Movie foundMovie = movieRepositoryRef.getMovieById(movieId);
		return foundMovie;
	}
	
	public void addNewMovie(Movie newMovie) {
		movieRepositoryRef.addNewMovie(newMovie);
	}
}







