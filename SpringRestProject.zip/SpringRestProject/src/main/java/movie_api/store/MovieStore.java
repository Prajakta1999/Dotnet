package movie_api.store;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import movie_api.entity.Movie;

public class MovieStore {//This class is used to maintain in-memory collection of Movie objects.
	private static Map<Integer, Movie> movieCollection;
	static {
		//This is used to instantiate the Map and store some values into it.
		movieCollection = new HashMap<>();
		Movie m1 = new Movie(101, "Evil Dead", "Horror", 1988);
		Movie m2 = new Movie(102, "Speed", "Thriller", 1997);
		Movie m3 = new Movie(103, "PK", "Fantasy", 2014);
		Movie m4 = new Movie(104, "Life of PI", "Emotional", 2012);
		Movie m5 = new Movie(105, "Gadar", "Action", 2001);
		
		movieCollection.put(m1.getMovieId(), m1);
		movieCollection.put(m2.getMovieId(), m2);
		movieCollection.put(m3.getMovieId(), m3);
		movieCollection.put(m4.getMovieId(), m4);
		movieCollection.put(m5.getMovieId(), m5);		
	}
	
	//Method to retrieve all available movies
	public static Collection<Movie> getAllAvailableMovies(){
		//Retrieving right side of the Map i.e values i.e. Movie objects
		Collection<Movie> allAvailableMovies = movieCollection.values();
		return allAvailableMovies;		
	}
	
	//Method to retrieve one movie against its ID
	public static Movie getMovieById(Integer movieId) {
		Movie foundMovie = movieCollection.get(movieId);
		return foundMovie;
	}
	
	//Method to add a new movie into the existing Map
	public static void addNewMovie(Movie newMovie) {
		movieCollection.put(newMovie.getMovieId(), newMovie);
	}
}












