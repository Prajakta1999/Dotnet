package movie_api.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import movie_api.entity.Movie;
import movie_api.exception.MovieNotFoundException;
import movie_api.service.MovieService;

@RestController
public class MovieController {
	//GET, /movie-api - To get all the movies
	@Autowired//Injecting the reference of MovieService
	private MovieService movieServiceRef;
	//@RequestMapping("/movie-api")
	@GetMapping("/movie-api")
	public Collection<Movie> getAllMovies(){
		Collection<Movie> allMovies = 	movieServiceRef.getAllMovies();
		return allMovies;		
	}
	//GET, /movie-api/{movie_id} - To get one movie against its ID
	//@RequestMapping("/movie-api/{movie_id}")
	@GetMapping("/movie-api/{movie_id}")
	public Movie getMovieById(@PathVariable("movie_id") Integer movieId) {
		Movie foundMovie = movieServiceRef.getMovieById(movieId);
		//System.out.println("Found Movie is : " + foundMovie);
		if(foundMovie == null) {
			//If movie not found then raise exception: MovieNotFoundException
			MovieNotFoundException ex = 
					new MovieNotFoundException("Unable to find movie with this ID", movieId);
			throw ex;
		}
		return foundMovie;
	}
	
	//POST, /movie-api
	//@RequestMapping(value = "/movie-api", method = RequestMethod.POST)
	@PostMapping("/movie-api")
	public void createNewMovie(@RequestBody Movie newMovie) {
		System.out.println("Object received: " + newMovie);
		movieServiceRef.addNewMovie(newMovie);
	}
}










